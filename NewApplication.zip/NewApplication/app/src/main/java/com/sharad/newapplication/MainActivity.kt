package com.sharad.newapplication


import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Adapter
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.sql.DriverManager.println
import kotlinx.android.synthetic.main.old_activity.*


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.old_activity)
        println("onCreate called")
        val serviceGenerator = ServiceGenerator.buildService(ApiService::class.java)
        val call = serviceGenerator.getPosts()
        val recyclerView=findViewById<RecyclerView>(R.id.recycler)



            call.enqueue(object : Callback<MutableList<PostModel>> {
                override fun onResponse(
                    call: Call<MutableList<PostModel>>,
                    response: Response<MutableList<PostModel>>) {
                    if (response.isSuccessful){
                       recyclerView.apply{
                           layoutManager=LinearLayoutManager(this@MainActivity)
                           adapter=PostAdapter(response.body()!!)

                       }
                    }

                }

                override fun onFailure(call: Call<MutableList<PostModel>>, t: Throwable) {
                    t.printStackTrace()
                    Log.e("error",t.message.toString())
                }


            })
            
        }

        






    override fun onStart() {
        super.onStart()
        println("onStart called")
    }
    override fun onResume() {
        super.onResume()
        println("onResume called")
    }

    override fun onPause() {
        super.onPause()
        println("onPaused called")

    }

    override fun onStop() {
        super.onStop()
        println("onStop called")

    }

    override fun onRestart() {
        super.onRestart()
        println("onRestart called")
    }

    override fun onDestroy() {
        super.onDestroy()
        println("onDestroy called")

    }


}
