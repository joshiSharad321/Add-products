package com.sharad.newapplication

 data class PostModel (
     val product_name: String? = null,
     val product_type: String? = null,
     val price: Int? = null,
     val tax: Int? = null
 )