package com.sharad.newapplication

import android.view.View
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PostAdapter {

}
class PostViewHolder(itemView:View):RecyclerView.ViewHolder(itemView) {
    private val nme: TextView = itemView.findViewById(R.id.nme)
    private val pte: TextView = itemView.findViewById(R.id.pte)
    private val pric: TextView = itemView.findViewById(R.id.pric)
    private val tAx: TextView = itemView.findViewById(R.id.tAx)
    fun bindView(postModel: PostModel){
        nme.text=postModel.product_name
        pte.text=postModel.product_type
        pric.text= postModel.price.toString()
        tAx.text=postModel.tax.toString()
}
}




